-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2018-01-08 09:15:43
-- 服务器版本： 5.7.20-log
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sim`
--
CREATE DATABASE IF NOT EXISTS `sim` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `sim`;

-- --------------------------------------------------------

--
-- 表的结构 `aliapi`
--

CREATE TABLE `aliapi` (
  `id` int(11) NOT NULL,
  `apiname` varchar(100) NOT NULL COMMENT '标题',
  `appcode` varchar(260) NOT NULL COMMENT '阿里云API市场得到的APPCODE',
  `isshow` int(2) NOT NULL DEFAULT '1' COMMENT '是否使用',
  `apihost` varchar(220) NOT NULL COMMENT 'host',
  `apipath` varchar(220) NOT NULL COMMENT 'path',
  `apimethod` varchar(10) NOT NULL DEFAULT 'GET' COMMENT 'method',
  `apiquerys` varchar(100) NOT NULL DEFAULT 'type=type' COMMENT 'type',
  `apibodys` varchar(200) DEFAULT '' COMMENT 'bodys'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

CREATE TABLE `article` (
  `Id` int(11) NOT NULL COMMENT '文章id',
  `Atitle` varchar(60) NOT NULL COMMENT '标题',
  `Acont` text NOT NULL COMMENT '内容',
  `Acont_top` varchar(200) NOT NULL COMMENT '摘要',
  `Fid` int(11) NOT NULL COMMENT '栏目ID',
  `Adate` varchar(10) NOT NULL COMMENT '日期',
  `isshow` int(5) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `zhuanti` int(5) NOT NULL DEFAULT '0' COMMENT '是否为专题0否 非0代表专题栏目ID',
  `photo` int(10) DEFAULT NULL COMMENT '封面图片ID',
  `tag` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL COMMENT '栏目id',
  `catetitle` varchar(20) NOT NULL COMMENT '栏目名',
  `fid` int(5) NOT NULL DEFAULT '0' COMMENT '位置',
  `url` varchar(20) NOT NULL COMMENT '链接地址',
  `icon` varchar(20) NOT NULL COMMENT '图标',
  `cont` text NOT NULL COMMENT '说明',
  `ismenu` int(5) NOT NULL DEFAULT '0' COMMENT '是否显示在导航',
  `isshow` int(5) NOT NULL DEFAULT '0' COMMENT '是否显示在循环列表',
  `orderid` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `zhuanti` int(2) NOT NULL DEFAULT '0' COMMENT '是否为专题栏目(子栏目)',
  `cmod` int(5) DEFAULT '0' COMMENT '指定模块'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `cname` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '参数名',
  `cvalue` varchar(200) CHARACTER SET utf8 NOT NULL COMMENT '参数值',
  `ccont` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '参数说明'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `config`
--

INSERT INTO `config` (`id`, `cname`, `cvalue`, `ccont`) VALUES
(12, 'sh1_site_name0', 'Hello John', '网站名称'),
(13, 'sh1_site_name1', 'welcome!', '网站标题'),
(14, 'sh1_site_key', '基于simAdmin开发', '网站关键字'),
(15, 'sh1_page_listnum0', '10', '前台列表项数量'),
(16, 'sh1_page_listnum1', '15', '后台列表项数量'),
(17, 'sh1_site_desc', '基于simAdmin开发', '网站描述'),
(18, 'sh1_site_copyright', '葫芦岛明远科技提供技术支持，本站基于simAdmin开发设计。', '网站底部文字'),
(21, 'sh1_user_level', '新秀,少侠,大侠,掌门,宗师,盟主', '会员等级'),
(22, 'sh1_user_type', '普通用户,企业用户,VIP用户', '会员类型'),
(25, 'sh1_page_bkc', '#ffffff', '指定背景颜色'),
(26, 'sh1_log_pwr', 'true', '系统日志开关（true/false）'),
(28, 'sh1_sys_guolv', '邪教,习近平', '脏字过滤(妈的,操你妈,习近平,邪教,溜冰)'),
(30, 'sim_text', 'hellojohn.cn', '网站介绍'),
(31, 'sim_pic', '/uploads/pic_2/20180103_115939972_8.jpg', '网站图片');

-- --------------------------------------------------------

--
-- 表的结构 `logmgr`
--

CREATE TABLE `logmgr` (
  `Id` int(11) NOT NULL COMMENT '日志id',
  `uname` varchar(50) NOT NULL COMMENT '用户ID',
  `Logdate` varchar(50) NOT NULL COMMENT '日期',
  `Action` varchar(50) NOT NULL COMMENT '操作名',
  `actcont` varchar(100) NOT NULL COMMENT '操作说明'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `managers`
--

CREATE TABLE `managers` (
  `id` int(11) NOT NULL COMMENT 'id',
  `uname` varchar(20) NOT NULL COMMENT '用户名',
  `upswd` varchar(50) NOT NULL COMMENT '密码',
  `utype` int(5) DEFAULT '1' COMMENT '权限区分'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `poster` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `datetime` int(11) NOT NULL,
  `stat` int(11) NOT NULL DEFAULT '0',
  `forsys` int(2) NOT NULL DEFAULT '0',
  `msg` varchar(200) NOT NULL,
  `tit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `model`
--

CREATE TABLE `model` (
  `id` int(11) NOT NULL,
  `mname` varchar(10) NOT NULL COMMENT '模块名',
  `mcid` varchar(100) NOT NULL COMMENT '需要的控件ID，逗号分开',
  `isshow` int(1) NOT NULL DEFAULT '1' COMMENT '是否显示'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `model_ctrls`
--

CREATE TABLE `model_ctrls` (
  `id` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL COMMENT '名称',
  `clen` int(10) NOT NULL DEFAULT '0' COMMENT '长度',
  `cinfo` varchar(60) DEFAULT NULL COMMENT '标记，简要说明',
  `cui` int(1) NOT NULL DEFAULT '0' COMMENT '0普通输入框，1激活图片库选择，2下拉列表，3启用编辑器,4选择图片库'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `model_items`
--

CREATE TABLE `model_items` (
  `id` int(11) NOT NULL,
  `model_id` int(10) NOT NULL COMMENT '所属模块',
  `ctrl_id` int(10) NOT NULL COMMENT '控件或规则id（ctrls）',
  `strval` text COMMENT '值',
  `sessc` varchar(100) NOT NULL COMMENT '整条数据标识',
  `orderid` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pic`
--

CREATE TABLE `pic` (
  `Id` int(11) NOT NULL COMMENT '图片库id',
  `pictitle` varchar(15) NOT NULL COMMENT '图库名称'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pic_item`
--

CREATE TABLE `pic_item` (
  `Id` int(11) NOT NULL COMMENT '图片表id',
  `Pictype` int(6) NOT NULL DEFAULT '0' COMMENT '图片类别',
  `Picurl` varchar(200) NOT NULL COMMENT '图片地址',
  `picid` int(11) NOT NULL COMMENT '所在图库ID',
  `pictit` varchar(50) DEFAULT NULL COMMENT '图片标题'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `tagname` varchar(50) NOT NULL,
  `isshow` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `Jifen` int(6) NOT NULL DEFAULT '0' COMMENT '积分',
  `Shengri` varchar(10) NOT NULL COMMENT '生日',
  `uType` varchar(20) NOT NULL COMMENT '用户类型',
  `weixin` varchar(20) NOT NULL DEFAULT '0' COMMENT '微信',
  `Usex` varchar(5) NOT NULL DEFAULT '男' COMMENT '性别',
  `Old` int(3) NOT NULL DEFAULT '0' COMMENT '年龄',
  `Umail` varchar(20) NOT NULL DEFAULT '@' COMMENT '邮件',
  `Phone` int(15) NOT NULL DEFAULT '0' COMMENT '手机',
  `Qq` int(20) NOT NULL DEFAULT '0' COMMENT 'QQ',
  `Realname` varchar(10) NOT NULL COMMENT '真实姓名',
  `yue` float NOT NULL DEFAULT '0' COMMENT '余额',
  `uname` varchar(20) NOT NULL COMMENT '用户名',
  `upswd` varchar(200) NOT NULL COMMENT 'MD5密码',
  `uleve` varchar(20) NOT NULL COMMENT '用户等级'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aliapi`
--
ALTER TABLE `aliapi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logmgr`
--
ALTER TABLE `logmgr`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_ctrls`
--
ALTER TABLE `model_ctrls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_items`
--
ALTER TABLE `model_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pic`
--
ALTER TABLE `pic`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `pic_item`
--
ALTER TABLE `pic_item`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `aliapi`
--
ALTER TABLE `aliapi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `article`
--
ALTER TABLE `article`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '文章id';

--
-- 使用表AUTO_INCREMENT `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '栏目id';

--
-- 使用表AUTO_INCREMENT `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- 使用表AUTO_INCREMENT `logmgr`
--
ALTER TABLE `logmgr`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志id';

--
-- 使用表AUTO_INCREMENT `managers`
--
ALTER TABLE `managers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id';

--
-- 使用表AUTO_INCREMENT `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `model`
--
ALTER TABLE `model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `model_ctrls`
--
ALTER TABLE `model_ctrls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `model_items`
--
ALTER TABLE `model_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `pic`
--
ALTER TABLE `pic`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '图片库id';

--
-- 使用表AUTO_INCREMENT `pic_item`
--
ALTER TABLE `pic_item`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT COMMENT '图片表id';

--
-- 使用表AUTO_INCREMENT `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
